onEvent('block.right_click', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.id == 'kubejs:andesite_bee_doll')
    if (event.block.id == 'minecraft:beehive'){
      event.server.schedule(5, event.server, function (callback) {
        let command = `execute as ${event.player.name} in ${event.player.world.dimension} run summon resourcefulbees:andesite_bee ${event.player.x} ${event.player.y} ${event.player.z}`
        callback.server.runCommandSilent(command);})
        if (!event.player.isCreativeMode()) {event.item.setCount(event.item.getCount() - 1)}}
        })
