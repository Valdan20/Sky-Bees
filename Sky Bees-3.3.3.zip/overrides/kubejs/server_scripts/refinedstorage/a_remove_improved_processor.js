onEvent('recipes', event => {
  event.remove({output: 'refinedstorage:improved_processor', type: 'minecraft:smelting'})
})
