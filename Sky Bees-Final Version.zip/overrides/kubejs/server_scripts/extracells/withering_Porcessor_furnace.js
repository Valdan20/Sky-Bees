onEvent('recipes', event => {
  event.remove({output: 'extradisks:withering_processor', type: 'minecraft:smelting'})
})
