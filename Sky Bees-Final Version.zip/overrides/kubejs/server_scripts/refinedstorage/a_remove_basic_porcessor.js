onEvent('recipes', event => {
  event.remove({output: 'refinedstorage:basic_processor', type: 'minecraft:smelting'})
})
