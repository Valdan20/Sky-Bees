onEvent('recipes', event => {
  event.custom(
{
  "type": "astralsorcery:block_transmutation",
  "input": [
    {
      "block": "minecraft:polished_diorite",
      "display": {
        "item": "minecraft:polished_diorite",
        "count": 1
      }
    }
  ],
  "output": {
    "block": "astralsorcery:marble_raw"
  },
  "display": {
    "item": "astralsorcery:marble_raw",
    "count": 1
  },
  "starlight": 100.0
}
)
})
